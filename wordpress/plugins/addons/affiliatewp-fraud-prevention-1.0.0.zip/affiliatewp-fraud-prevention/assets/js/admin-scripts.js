jQuery( function( $ ) {
	'use strict';

	/**
	 * Object to handle Paystack admin functions.
	 */
	let affwp_fraud_prevention = {
		/**
		 * Initialize.
		 */
		init: function() {

			let conversionRate      = $( 'input[name="affwp_settings[fraud_prevention_conversion_rate]"]' ),
				min_conversion_rate = $( '#fraud_prevention_min_conversion_rate' ),
				max_conversion_rate = $( '#fraud_prevention_max_conversion_rate' );

			conversionRate.click( function() {
				if ( 'flag' === $( this ).val() ) {
					min_conversion_rate.show();
					max_conversion_rate.show();
				} else {
					min_conversion_rate.hide();
					max_conversion_rate.hide();
				}
			} );

			if ( conversionRate.filter( ':checked' ).val() === 'allow' ) {
				min_conversion_rate.hide();
				max_conversion_rate.hide();
			}
		}
	};

	affwp_fraud_prevention.init();

} );

document.addEventListener( 'DOMContentLoaded', () => {
	tippy( '[data-tippy-content]', {
		interactive: true,
		inlinePositioning: true,
		placement: 'right',
		zIndex: 9999

		//	maxWidth: 150
		//	appendTo: '.wp-list-table'
	} );
} );