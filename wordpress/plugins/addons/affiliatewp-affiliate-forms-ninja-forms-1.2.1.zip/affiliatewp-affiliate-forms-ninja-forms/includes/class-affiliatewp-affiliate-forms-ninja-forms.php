<?php
/**
 * Affiliate Forms For Ninja Forms Plugin Bootstrap
 *
 * @package     AffiliateWP Affiliate Forms For Ninja Forms
 * @subpackage  Core
 * @copyright   Copyright (c) 2021, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Conditionally load NF 2.x files if needed.
 *
 * If Ninja Forms 2.x is active, load the deprecated AFNF plugin files.
 *
 * @since  1.1
 *
 * @return void
 */
if ( get_option( 'ninja_forms_version') && get_option( 'ninja_forms_load_deprecated') ) {

	if( version_compare( get_option( 'ninja_forms_version', '0.0.0' ), '3.0', '>' ) || get_option( 'ninja_forms_load_deprecated', false ) ) {

		include plugin_dir_path( __FILE__ ) . 'deprecated/load-deprecated.php';

	}
} else {

	/**
	 * AffiliateWP_Affiliate_Forms_For_Ninja_Forms class.
	 */
	final class AffiliateWP_Affiliate_Forms_For_Ninja_Forms {

		/**
		 * Holds the instance
		 *
		 * Ensures that only one instance of AffiliateWP_Affiliate_Forms_For_Ninja_Forms
		 * exists in memory at any one time.
		 *
		 * @var object
		 * @static
		 * @since 1.0
		 */
		private static $instance;

		/**
		 * The version number of Affiliate Forms for Ninja Forms
		 *
		 * @since 1.0
		 * @since 1.2 static keyword removed
		 */
		private $version = '1.2.1';

		/**
		 * Main plugin file.
		 *
		 * @since 1.2
		 * @var   string
		 */
		private $file = '';

		/**
		 * The affiliate registration handler instance variable
		 *
		 * @var Affiliate_WP_Register
		 * @since 1.0
		 */
		public $register;

		/**
		 * Plugin directory
		 *
		 * @var string
		 */
		public static $dir;

		/**
		 * Plugin url
		 *
		 * @var string
		 */
		public static $url;

		/**
		 * AffiliateWP_Affiliate_Forms_For_Ninja_Forms instance.
		 *
		 * @since 1.0
		 * @static
		 *
		 * @param string $file Main plugin file.
		 * @return \AffiliateWP_Affiliate_Forms_For_Ninja_Forms The one true AffiliateWP_Affiliate_Portal instance.
		 */
		public static function instance( $file = null ) {

			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof AffiliateWP_Affiliate_Forms_For_Ninja_Forms ) ) {

				self::$instance       = new AffiliateWP_Affiliate_Forms_For_Ninja_Forms();
				self::$instance->file = $file;

				self::$instance->setup_constants();
				self::$instance->load_textdomain();
				self::$instance->includes();
				self::$instance->init();
			}

			return self::$instance;
		}

		/**
		 * Throw error on object clone
		 *
		 * The whole idea of the singleton design pattern is that there is a single
		 * object therefore, we don't want the object to be cloned.
		 *
		 * @since 1.0
		 * @access protected
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'affiliatewp-afnf' ), '1.0' );
		}

		/**
		 * Disable unserializing of the class
		 *
		 * @since 1.0
		 * @access protected
		 * @return void
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'affiliatewp-afnf' ), '1.0' );
		}

		/**
		 * Setup plugin constants.
		 *
		 * @access private
		 * @since  1.2
		 *
		 * @return void
		 */
		private function setup_constants() {
			// Plugin version
			if ( ! defined( 'AFFWP_AFNF_VERSION' ) ) {
				define( 'AFFWP_AFNF_VERSION', $this->version );
			}

			// Plugin Folder Path
			if ( ! defined( 'AFFWP_AFNF_PLUGIN_DIR' ) ) {
				define( 'AFFWP_AFNF_PLUGIN_DIR', plugin_dir_path( $this->file ) );
			}

			// Plugin Folder URL
			if ( ! defined( 'AFFWP_AFNF_PLUGIN_URL' ) ) {
				define( 'AFFWP_AFNF_PLUGIN_URL', plugin_dir_url( $this->file ) );
			}

			// Plugin Root File
			if ( ! defined( 'AFFWP_AFNF_PLUGIN_FILE' ) ) {
				define( 'AFFWP_AFNF_PLUGIN_FILE', $this->file );
			}
		}

		/**
		 * Init
		 *
		 * @access private
		 * @since  1.1.8
		 * @return void
		 */
		private function init() {
			if ( is_admin() ) {
				$this->updater();
			}

			/**
			 * Register an NF3 field section
			 */
			add_filter( 'ninja_forms_field_type_sections', array( $this, 'register_section' ) );

			/**
			 * Register NF3 merge tag for the affiliate area
			 *
			 */
			add_filter( 'ninja_forms_merge_tags_other', array( $this, 'register_merge_tag') );

			/**
			 * Enqueue js for front-end validation.
			 */
			add_action( 'ninja_forms_enqueue_scripts', array( $this, 'scripts') );

			add_filter( 'ninja_forms_pre_validate_field_settings', array( $this, 'remove_required_password_for_logged_in_users' ) );

			add_filter( 'ninja_forms_submit_data', array( $this, 'add_field_type_to_submitted_fields' ) );

		}

		/**
		 * Reset the instance of the class
		 *
		 * @since 1.0
		 * @access public
		 * @static
		 */
		public static function reset() {
			self::$instance = null;
		}

		/**
		 * Loads the plugin language files.
		 *
		 * @access public
		 * @since  1.0
		 * @return void
		 */
		public function load_textdomain() {

			// Set filter for plugin's languages directory
			$lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
			$lang_dir = apply_filters( 'affiliatewp_afnf_languages_directory', $lang_dir );

			// Traditional WordPress plugin locale filter
			$locale   = apply_filters( 'plugin_locale',  get_locale(), 'affiliatewp-afnf' );
			$mofile   = sprintf( '%1$s-%2$s.mo', 'affiliatewp-afnf', $locale );

			// Setup paths to current locale file
			$mofile_local  = $lang_dir . $mofile;
			$mofile_global = WP_LANG_DIR . '/affiliatewp-afnf/' . $mofile;

			if ( file_exists( $mofile_global ) ) {
				// Look in global /wp-content/languages/affiliatewp-afnf/ folder
				load_textdomain( 'affiliatewp-afnf', $mofile_global );
			} elseif ( file_exists( $mofile_local ) ) {
				// Look in local /wp-content/plugins/affiliatewp-afnf/languages/ folder
				load_textdomain( 'affiliatewp-afnf', $mofile_local );
			} else {
				// Load the default language files
				load_plugin_textdomain( 'affiliatewp-afnf', false, $lang_dir );
			}
		}

		/**
		 * Require necessary files for
		 * Ninja Forms 3.0 or higher.
		 *
		 * @access      private
		 * @since       1.1
		 * @return      void
		 */
		public function includes() {

			if ( is_admin() ) {
				// Admin Hooks
				require_once AFFWP_AFNF_PLUGIN_DIR . 'includes/admin.php';
			}

			// Functions
			require_once AFFWP_AFNF_PLUGIN_DIR . 'includes/functions.php';

			// Email Tags
			require_once AFFWP_AFNF_PLUGIN_DIR . 'includes/email-tags.php';

			// Shortcodes
			require_once AFFWP_AFNF_PLUGIN_DIR . 'includes/templates.php';

		}

		/**
		 * Register Ninja Forms 3 section.
		 *
		 * Responsible for registering the `affiliatewp`
		 * Ninja Forms field section.
		 *
		 * Ninja Forms field sections must appear on all NF forms during registration.
		 *
		 * @since  1.1
		 *
		 * @param  array  $sections An array of Ninja Forms sections
		 *
		 * @return array  $sections An array of Ninja Forms sections
		 */
		public function register_section( $sections ) {

			$sections[ 'affiliatewp' ] = array(
				'id'            => 'affiliatewp',
				'nicename'      => __( 'AffiliateWP', 'affiliatewp-afnf' ),
				'classes'       => 'affwp-afnf',
				'fieldTypes'    => array()
				);

			return $sections;
		}

		/**
		 * Modify plugin metalinks.
		 *
		 * @access      public
		 * @since       1.0
		 * @param       array $links The current links array
		 * @param       string $file A specific plugin table entry
		 * @return      array $links The modified links array
		 */
		public function plugin_meta( $links, $file ) {
			if ( $file == plugin_basename( __FILE__ ) ) {
				$plugins_link = array(
					'<a title="' . __( 'Get more add-ons for AffiliateWP', 'affiliatewp-afnf' ) . '" href="http://affiliatewp.com/addons/" target="_blank">' . __( 'Get add-ons', 'affiliatewp-afnf' ) . '</a>'
				);

				$links = array_merge( $links, $plugins_link );
			}

			return $links;
		}

		/**
		 * Adds an affiliate area url merge tag
		 * to Ninja Forms System merge tags
		 *
		 * @since  1.1
		 *
		 * @param  array  $merge_tags Form merge tags available
		 *
		 * @return array              Form merge tags
		 */
		public function register_merge_tag( $merge_tags ) {

			$merge_tags['affwp_afnf_affiliate_area_url'] = array(
				'id'       => 'affwp_afnf_affiliate_area_url',
				'tag'      => '{other:affwp_afnf_affiliate_area_url}',
				'label'    => __( 'Affiliate Area URL', 'affiliatewp-afnf' ),
				'callback' => array( $this, 'get_affiliate_area_url' ),
			);

			return $merge_tags;
		}

		/**
		 * Get the affiliate area url
		 *
		 * @since  1.1
		 *
		 * @return string  The affiliate area url
		 */
		public function get_affiliate_area_url() {
			if ( ! function_exists( 'affwp_get_affiliate_area_page_url' ) ) {
				return;
			}

			$url = esc_url( affwp_get_affiliate_area_page_url() );

			return $url;
		}

		/**
		 * Enqueue javascript responsible
		 * for client-side field validation.
		 *
		 * @since  1.1
		 *
		 * @return void
		 */
		public function scripts() {

			$suffix = ( defined( 'AFFILIATE_WP_DEBUG' ) && AFFILIATE_WP_DEBUG || defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG  ) || ( isset( $_GET['script_debug'] ) ) ? '' : '.min';

			$src = plugins_url( "assets/js/affiliatewp-afnf{$suffix}.js", __FILE__ );

			wp_register_script( 'affiliatewp-afnf', $src, array( 'jquery' ), null, true );

			$logged_in          = ( is_user_logged_in() ) ? true : false;
			$debug              = affiliate_wp()->settings->get( 'debug_mode' );
			$user               = $logged_in ? wp_get_current_user() : false;
			$user_email         = $user ? $user->user_email : false;
			$maybe_affiliate    = $user ? affiliate_wp()->affiliates->get_by( 'user_id', $user->ID ) : false;
			$afnf_form_id       = affwp_ninja_forms_three_get_registration_form_id();

			// Get AFNF Email Field ID from action settings.
			$afnf_email_id     = 0;
			$afnf_form_actions = Ninja_Forms()->form( $afnf_form_id )->get_actions();
			foreach ( $afnf_form_actions as $action ) {
				$settings = $action->get_settings();
				// Search for AFNF action.
				if ( 'affwp_afnf_register' === $settings['type'] ) {
					$email_field = $settings['email'];
					preg_match( '/{field:([a-zA-Z0-9_]+)}/', $email_field, $matches );
					if ( count( $matches ) > 0 ) {
						$email_field_key = $matches[1];

						// Get field with same key to get its ID.
						$afnf_form_fields = Ninja_Forms()->form( $afnf_form_id )->get_fields();
						foreach ( $afnf_form_fields as $field ) {
							if ( $field->get_settings()['key'] === $email_field_key ) {
								$afnf_email_id = $field->get_id();
								break;
							}
						}
					}

					break;
				}
			}

			$fields             = array(
				'ajax_url'               => admin_url( 'admin-ajax.php' ),
				'email_exists'           => function( $email = '' ) {
					if ( email_exists( $email ) ) {
						return true;
					} else {
						return false;
					}
					return false;
				},
				'logged_in'              => $logged_in,
				'is_valid_affiliate'     => $maybe_affiliate,
				'user_email'             => $user_email,
				'error_email'            => __( 'Affiliate registration requires a valid email address', 'affiliatewp-afnf' ),
				'error_email_exists'     => __( 'Email address already in use. Please choose a different email address', 'affiliatewp-afnf' ),
				'error_username'         => __( 'Affiliate registration requires a valid username', 'affiliatewp-afnf' ),
				'error_missing_fields'   => __( 'Affiliate registration forms requires a valid email field. It is also recommended to add a username field. Return to the form and add the missing required field, or contact the site administrator.', 'affiliatewp-afnf' ),
				'error_missing_email'    => __( 'Affiliate registration forms require a valid email field. Return to the form and add the missing email field, or contact the site administrator.', 'affiliatewp-afnf' ),
				'error_missing_username' => __( 'Affiliate registration forms require a valid username field. Please enter your desired username.', 'affiliatewp-afnf' ),
				'error_email_empty'      => __( 'Please provide an email address.', 'affiliatewp-afnf' ),
				'afnf_form_id'           => $afnf_form_id,
				'afnf_email_id'          => $afnf_email_id,
			);

			wp_localize_script( 'affiliatewp-afnf', 'affiliatewp_afnf', $fields );

			wp_enqueue_script( 'affiliatewp-afnf' );
		}

		/**
		 * Load the custom plugin updater.
		 *
		 * @access private
		 * @since 1.0
		 * @return void
		 */
		public function updater() {

			if ( class_exists( 'AffWP_AddOn_Updater' ) ) {
				$updater = new AffWP_AddOn_Updater( 23789, __FILE__, $this->version );
			}
		}

		/**
		 * Removes required password for logged in users when validating password and passwordConfirm fields.
		 *
		 * @since 1.1.13
		 *
		 * @param array $field_settings The field to be validated settings.
		 * @return array (Maybe) modified field settings.
		 */
		public function remove_required_password_for_logged_in_users( $field_settings ) {
			if ( is_user_logged_in() && isset( $_POST['formData'] ) ) {
				// Get form data.
				$form_data = json_decode( $_POST['formData'], true );

				// Check if form is the AffiliateWP form.
				$form_id      = $form_data['id'];
				$afnf_form    = affiliate_wp()->settings->get( 'affwp_afnf_form' );
				$is_afnf_form = absint( $form_id ) === absint( $afnf_form ) ? true : false;

				// Remove required for password and passwordConfirm types.
				if ( $is_afnf_form && ( 'password' === $field_settings['type'] || 'passwordconfirm' === $field_settings['type'] ) ) {
					$field_settings['required'] = 0;
				}
			}

			return $field_settings;
		}

		/**
		 * Adds field type to form data being submitted for password and passwordConfirm fields.
		 *
		 * @since 1.1.13
		 *
		 * @param array $form_data The form data submitted.
		 * @return array (Maybe) modified form data.
		 */
		public function add_field_type_to_submitted_fields( $form_data ) {
			// NF PasswordConfirm needs the submitted fields to have its type (PasswordConfirm.php:64).
			foreach ( $form_data['fields'] as $key => $field ) {

				if ( false !== strpos( $field['key'], 'passwordconfirm' ) ) {

					$form_data['fields'][ $key ]['type'] = 'passwordconfirm';

				} elseif ( false !== strpos( $field['key'], 'password' ) ) {

					$form_data['fields'][ $key ]['type'] = 'password';

				} else {

					$form_data['fields'][ $key ]['type'] = '';

				}
			}
			return $form_data;
		}

	}

	/**
	 * The main function responsible for the
	 * AffiliateWP_Affiliate_Forms_For_Ninja_Forms
	 * instance to functions everywhere.
	 *
	 * @since  1.1
	 * @return \AffiliateWP_Affiliate_Forms_For_Ninja_Forms instance
	 */
	function affiliatewp_afnf() {
		return \AffiliateWP_Affiliate_Forms_For_Ninja_Forms::instance();
	}
}
